# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Cast>` | `<cast>` (components/Cast.vue)
- `<Ckeditor>` | `<ckeditor>` (components/Ckeditor.vue)
- `<HomeHeader>` | `<home-header>` (components/HomeHeader.vue)
- `<Login>` | `<login>` (components/Login.vue)
- `<Register>` | `<register>` (components/Register.vue)
- `<CommentComponentAddComent>` | `<comment-component-add-coment>` (components/CommentComponent/AddComent.vue)
- `<CommentComponentDisplayComment>` | `<comment-component-display-comment>` (components/CommentComponent/DisplayComment.vue)
- `<CommentComponentSingleComment>` | `<comment-component-single-comment>` (components/CommentComponent/SingleComment.vue)
- `<CategoryComponentAddCategory>` | `<category-component-add-category>` (components/CategoryComponent/AddCategory.vue)
- `<CategoryHeader>` | `<category-header>` (components/CategoryComponent/CategoryHeader.vue)
- `<CategoryComponentListCategory>` | `<category-component-list-category>` (components/CategoryComponent/ListCategory.vue)
- `<CategoryComponentListCategoryAdmin>` | `<category-component-list-category-admin>` (components/CategoryComponent/ListCategoryAdmin.vue)
- `<PostComponentCreatePostForm>` | `<post-component-create-post-form>` (components/PostComponent/CreatePostForm.vue)
- `<PostHeader>` | `<post-header>` (components/PostComponent/PostHeader.vue)
- `<PostModal>` | `<post-modal>` (components/PostComponent/PostModal.vue)
- `<PostComponentRandomPost>` | `<post-component-random-post>` (components/PostComponent/RandomPost.vue)
- `<ViewsFooter>` | `<views-footer>` (components/Views/Footer.vue)
- `<ViewsShowAds>` | `<views-show-ads>` (components/Views/ShowAds.vue)
- `<ViewsStatsNav>` | `<views-stats-nav>` (components/Views/StatsNav.vue)
