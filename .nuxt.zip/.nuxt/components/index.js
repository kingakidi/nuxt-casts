export const Cast = () => import('../..\\components\\Cast.vue' /* webpackChunkName: "components/cast" */).then(c => wrapFunctional(c.default || c))
export const Ckeditor = () => import('../..\\components\\Ckeditor.vue' /* webpackChunkName: "components/ckeditor" */).then(c => wrapFunctional(c.default || c))
export const HomeHeader = () => import('../..\\components\\HomeHeader.vue' /* webpackChunkName: "components/home-header" */).then(c => wrapFunctional(c.default || c))
export const Login = () => import('../..\\components\\Login.vue' /* webpackChunkName: "components/login" */).then(c => wrapFunctional(c.default || c))
export const Register = () => import('../..\\components\\Register.vue' /* webpackChunkName: "components/register" */).then(c => wrapFunctional(c.default || c))
export const CommentComponentAddComent = () => import('../..\\components\\CommentComponent\\AddComent.vue' /* webpackChunkName: "components/comment-component-add-coment" */).then(c => wrapFunctional(c.default || c))
export const CommentComponentDisplayComment = () => import('../..\\components\\CommentComponent\\DisplayComment.vue' /* webpackChunkName: "components/comment-component-display-comment" */).then(c => wrapFunctional(c.default || c))
export const CommentComponentSingleComment = () => import('../..\\components\\CommentComponent\\SingleComment.vue' /* webpackChunkName: "components/comment-component-single-comment" */).then(c => wrapFunctional(c.default || c))
export const CategoryComponentAddCategory = () => import('../..\\components\\CategoryComponent\\AddCategory.vue' /* webpackChunkName: "components/category-component-add-category" */).then(c => wrapFunctional(c.default || c))
export const CategoryHeader = () => import('../..\\components\\CategoryComponent\\CategoryHeader.vue' /* webpackChunkName: "components/category-header" */).then(c => wrapFunctional(c.default || c))
export const CategoryComponentListCategory = () => import('../..\\components\\CategoryComponent\\ListCategory.vue' /* webpackChunkName: "components/category-component-list-category" */).then(c => wrapFunctional(c.default || c))
export const CategoryComponentListCategoryAdmin = () => import('../..\\components\\CategoryComponent\\ListCategoryAdmin.vue' /* webpackChunkName: "components/category-component-list-category-admin" */).then(c => wrapFunctional(c.default || c))
export const PostComponentCreatePostForm = () => import('../..\\components\\PostComponent\\CreatePostForm.vue' /* webpackChunkName: "components/post-component-create-post-form" */).then(c => wrapFunctional(c.default || c))
export const PostHeader = () => import('../..\\components\\PostComponent\\PostHeader.vue' /* webpackChunkName: "components/post-header" */).then(c => wrapFunctional(c.default || c))
export const PostModal = () => import('../..\\components\\PostComponent\\PostModal.vue' /* webpackChunkName: "components/post-modal" */).then(c => wrapFunctional(c.default || c))
export const PostComponentRandomPost = () => import('../..\\components\\PostComponent\\RandomPost.vue' /* webpackChunkName: "components/post-component-random-post" */).then(c => wrapFunctional(c.default || c))
export const ViewsFooter = () => import('../..\\components\\Views\\Footer.vue' /* webpackChunkName: "components/views-footer" */).then(c => wrapFunctional(c.default || c))
export const ViewsShowAds = () => import('../..\\components\\Views\\ShowAds.vue' /* webpackChunkName: "components/views-show-ads" */).then(c => wrapFunctional(c.default || c))
export const ViewsStatsNav = () => import('../..\\components\\Views\\StatsNav.vue' /* webpackChunkName: "components/views-stats-nav" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
