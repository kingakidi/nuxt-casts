import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _20e24846 = () => interopDefault(import('..\\pages\\castUser.vue' /* webpackChunkName: "pages/castUser" */))
const _c93c3f9e = () => interopDefault(import('..\\pages\\category\\index.vue' /* webpackChunkName: "pages/category/index" */))
const _f20b4e74 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _a617d474 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages/profile" */))
const _02bc8fe5 = () => interopDefault(import('..\\pages\\users.vue' /* webpackChunkName: "pages/users" */))
const _619c3ad9 = () => interopDefault(import('..\\pages\\category\\_id.vue' /* webpackChunkName: "pages/category/_id" */))
const _855a94a2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _62e2666a = () => interopDefault(import('..\\pages\\_id\\index.vue' /* webpackChunkName: "pages/_id/index" */))
const _664fa8fa = () => interopDefault(import('..\\pages\\_id\\_slug.vue' /* webpackChunkName: "pages/_id/_slug" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/castUser",
    component: _20e24846,
    name: "castUser"
  }, {
    path: "/category",
    component: _c93c3f9e,
    name: "category"
  }, {
    path: "/login",
    component: _f20b4e74,
    name: "login"
  }, {
    path: "/profile",
    component: _a617d474,
    name: "profile"
  }, {
    path: "/users",
    component: _02bc8fe5,
    name: "users"
  }, {
    path: "/category/:id",
    component: _619c3ad9,
    name: "category-id"
  }, {
    path: "/",
    component: _855a94a2,
    name: "index"
  }, {
    path: "/:id",
    component: _62e2666a,
    name: "id"
  }, {
    path: "/:id/:slug",
    component: _664fa8fa,
    name: "id-slug"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
